var BASE_URL = "https://jmd8.com";
try {
    if (CONFIG_URL) BASE_URL = CONFIG_URL;
} catch (error) {
}

var WORKERS = [
    "https://rotate-image-01.rotate-image.workers.dev",
    "https://rotate-image-02.rotate-image.workers.dev",
    "https://rotate-image-03.rotate-image.workers.dev",
    "https://rotate-image-04.rotate-image.workers.dev",
    "https://rotate-image-05.rotate-image.workers.dev",
    "https://rotate-image-06.rotate-image.workers.dev",
    "https://rotate-image-07.rotate-image.workers.dev",
    "https://rotate-image-08.rotate-image.workers.dev",
    "https://rotate-image-09.rotate-image.workers.dev",
    "https://rotate-image-10.rotate-image.workers.dev"
];

var BROKEN_COMICS = [
    "我和儿子的秘密",
    "斗罗玉传",
    "陈乔安传",
    "一夜暴富",
    "我是你爸系列",
    "做韵律操的妈妈",
    "寝取他人人妻",
    "我与骚姐们的配种生活",
    "秘密番外-陈梦雪篇",
    "教师妈妈很淫荡之奸淫美母",
    "焚心烈炎",
    "封我为尊第一季",
    "被学生威胁的丝袜老师李若雪",
    "星梦苍穹+外传+赌债偿还",
    "精灵救世主",
    "雯雅婷",
    "丝袜淫娃女教师",
    "神雕秘传大都篇",
    "绿帽满汉全席",
    "秘密"
];